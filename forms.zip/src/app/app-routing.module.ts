import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TemplatedrivenComponent } from './templatedriven/templatedriven.component';
import { RegSuccessComponent } from './reg-success/reg-success.component';
import { ReactivedrivenComponent } from './reactivedriven/reactivedriven.component';

const routes: Routes = [
  {path:'template',component:TemplatedrivenComponent},
  {path:'regSuccess',component:RegSuccessComponent},
  {path:'reactive',component:ReactivedrivenComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
