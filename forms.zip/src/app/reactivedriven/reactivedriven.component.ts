import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators, FormArray } from '@angular/forms';
import { PasswordValidator } from '../password.validator';
import { Router } from '@angular/router';
import { ForbiddenNameValidator } from '../username-validator';

@Component({
  selector: 'app-reactivedriven',
  templateUrl: './reactivedriven.component.html',
  styleUrls: ['./reactivedriven.component.css']
})
export class ReactivedrivenComponent implements OnInit {

  //using formBuilder instead of formGroup
  constructor(private fb:FormBuilder,private route:Router) { }

  registrationForm:FormGroup;

  ngOnInit(): void {
  
    this.registrationForm=this.fb.group({
      username:['Raj',[Validators.required,Validators.minLength(3),ForbiddenNameValidator]],
      password:[''],
      confirmPassword:[''],
      email:[''],
      subscribe:[],
      address:this.fb.group({
        city:[''],
        state:[''],
        postalCode:[''] 
    }),
    alternateEmails:this.fb.array([])
  },{validator:PasswordValidator});

  this.registrationForm.get('subscribe').valueChanges
      .subscribe(checkedValue => {
        const email = this.registrationForm.get('email');
        if (checkedValue) {
          email.setValidators(Validators.required);
        } else {
          email.clearValidators();
        }
        email.updateValueAndValidity();
      });

    }

  get username()
  {
    return this.registrationForm.get('username');
  }

  get email()
  {
    return this.registrationForm.get('email');
  }

  get alternateEmails()
  {
    return this.registrationForm.get('alternateEmails') as FormArray;
  }

  addAlternateEmail()
  {
    this.alternateEmails.push(this.fb.control(''));
  }
  submitted = false;
 
  onSubmit() {
    console.log("clicked");
    this.submitted = true;
    if(this.submitted==true){
    this.route.navigate(['/regSuccess']);
    }
  }

  //using form group
  /*
  registrationForm=new FormGroup({
    username: new FormControl('Sam'),
    password:new FormControl(''),
    confirmPassword:new FormControl(''),
    address:new FormGroup({
      city:new FormControl(''),
      state:new FormControl(''),
      postalCode:new FormControl('') 
    })
  });
  */


  //Adding default values to all values using setValue()
  /*loadApiData()
  {
    this.registrationForm.setValue({
      username:'Ram',
      password:'test',
      confirmPassword:'test',
      address:{
        city:'Chennai',
        state:'Tamil Nadu',
        postalCode:672552
      }
    });
  }*/

  //Adding default values to particular desired values using patchValue()
  loadApiData()
  {
    this.registrationForm.patchValue({
      username:'Syam',
      password:'pswd',
      confirmPassword:'pswd',
    });
  }


}
