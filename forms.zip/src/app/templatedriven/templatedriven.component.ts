import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { Router } from '@angular/router';

@Component({
  selector: 'app-templatedriven',
  templateUrl: './templatedriven.component.html',
  styleUrls: ['./templatedriven.component.css']
})
export class TemplatedrivenComponent implements OnInit {

  topics=['Angular',"react",'vue'];

  userModel=new User("Bob","bob@gmail.com",23456345,"default","morning",true);
  constructor(private route:Router) { }

  ngOnInit(): void {
  }
  
  submitted = false;
 
  onSubmit() {
    console.log("clicked");
    this.submitted = true;
    if(this.submitted==true){
    this.route.navigate(['/regSuccess']);
    }
  }

  topicHasError=true;

  validateTopic(value){
    if(value==="default"){
    this.topicHasError=true;
      }
    else{
        this.topicHasError=false;
    }
  }

}
     