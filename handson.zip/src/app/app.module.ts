import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ViewEmpComponent } from './view-emp/view-emp.component';
import { EditEmpComponent } from './edit-emp/edit-emp.component';
import { QuantityIncrementComponent } from './quantity-increment/quantity-increment.component';
import { EditEmpTemplateDrivenComponent } from './edit-emp-template-driven/edit-emp-template-driven.component';

@NgModule({ 
  declarations: [
    AppComponent,
    ViewEmpComponent,
    EditEmpComponent, 
    QuantityIncrementComponent, EditEmpTemplateDrivenComponent
  ],       
  imports: [            
    BrowserModule,
    AppRoutingModule,
    FormsModule   

  ], 
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }     