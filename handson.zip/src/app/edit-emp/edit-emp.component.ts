import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-emp',
  templateUrl: './edit-emp.component.html',
  styleUrls: ['./edit-emp.component.css']
})
export class EditEmpComponent implements OnInit {
msg:string;
  constructor() { }
 
  ngOnInit(): void {
  }
  clickEvent()
{
  this.msg='Click me button is clicked';
    return this.msg;
}

}
 