import { Skill } from "./Skill";

export interface Employee
{
    id:number;
    name:string;
    date:string;
    gender:String;
    salary:number;
    skill:Skill[];
}
