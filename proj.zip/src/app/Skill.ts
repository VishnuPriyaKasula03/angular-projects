import { NumberSymbol } from "@angular/common";

export interface Skill
{
    skill_id:number;
    skill_name:string;
}