import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
 // template: `<h2>Vishnu Priya Kasula</h2>`,
  templateUrl: './app.component.html',
 styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'proj';
  p="Kanna";
  is:boolean=true;
} 
   