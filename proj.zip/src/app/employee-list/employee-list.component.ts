import { Component, OnInit } from '@angular/core';
import { Employee } from '../Employee';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
 
  constructor() { }

  ngOnInit(): void {
  }
  empl:Employee[]=[
    { id:100,
      name:"Ramesh",
      date:"10/12/2020",
      gender:"Male",
      salary:2000000,
      skill:[
        {skill_id:10,skill_name:"Java"},
        {skill_id:11,skill_name:"C++"}
    ]},
    { id:1045,
      name:"Harshini",
      date:"12/10/2000",
      gender:"Female",
      salary:899000,
      skill:[
        {skill_id:10,skill_name:"PHP"},
        {skill_id:11,skill_name:"VLSI++"}
    ]},
    { id:101,
      name:"Harini",
      date:"12/10/2000",
      gender:"Female",
      salary:899000,
      skill:[
        {skill_id:10,skill_name:"PHP"},
        {skill_id:11,skill_name:"VLSI++"}
    ]},
    { id:102,
      name:"Rajesh",
      date:"12/03/2000",
      gender:"Male", 
      salary:90000000,
      skill:[ 
        {skill_id:10,skill_name:"Full Stack"},
        {skill_id:11,skill_name:"Pega"}
    ]}, 
    { id:103,
      name:"Kanna",
      date:"10/16/2000",
      gender:"Male",
      salary:20004567000,
      skill:[
        {skill_id:10,skill_name:"C"},
        {skill_id:11,skill_name:"DIP"}
    ]},
    { id:104,
      name:"Ravi",
      date:"12/10/2000",
      gender:"Male",
      salary:1000000,
      skill:[
        {skill_id:10,skill_name:"Nodejs"},
        {skill_id:11,skill_name:"Scratch"}
    ]}
  ];
  getTotalEmployeeCount():number{
    return this.empl.length;
  }
  getTotalMaleEmployeeCount():number{
    return this.empl.filter(e=>e.gender==='Male').length;
  }
  getTotalFemaleEmployeeCount():number{
    return this.empl.filter(e=>e.gender==='Female').length;
  }

  selectedEmployeeCountRadioButton:string="All"; 

  onEmployeeCountRadioButtonChange(selectedRadioValue:string):void{
    this.selectedEmployeeCountRadioButton=selectedRadioValue;
  }


}
