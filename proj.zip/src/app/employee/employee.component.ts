import { Component, OnInit } from '@angular/core';
import { Employee } from '../Employee';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  emp:Employee=
  {
    id:100,
    name:"Ramesh",
    date:"10/10/2000",
    gender:"Male",
    salary:2000000,
    skill:[
      {skill_id:10,skill_name:"Java"},
      {skill_id:11,skill_name:"C++"},
      {skill_id:13,skill_name:"Python"}
  ]
  }
 
}    
 