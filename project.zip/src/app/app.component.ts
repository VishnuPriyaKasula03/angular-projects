import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'project';
  pageHeader:string="Employee Details";
  imagePath:string="Harry-Potter-Sample-with-background.jpeg";

  isDisabled:boolean=true;

  event ={id:10,name:"Raju",price:4000,location:"chennai"};

  columnSpan:number=2;

  classesToApply: string="italicsClass boldClass";

  isBold:boolean=false;
  favouriteMovie:string="Lord of the Rings";

  add():void{
    console.log("button clicked");
  }
}
