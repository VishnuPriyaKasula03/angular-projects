import { Component, OnInit } from '@angular/core';
import { Employee } from '../Employee';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit
 {
   emp:Employee={
     id:10,
     name:"ramu",
     date:"05/09/2000",
     gender:"male",
     salary:200000,
     skill:[
       {skill_id:100,skill_name:"C++"},
       {skill_id:200,skill_name:"JAVA"},
       {skill_id:300,skill_name:"Python"}
     ]
   };

   showDetails:boolean=false;


   toggleDetails():void{
     this.showDetails=!this.showDetails;
   }
  constructor() { }

  ngOnInit(): void {
  }

  empl:Employee[]=[ 
    {id:10,name:"Ram",date:"10/12/2000",gender:"male",salary:300000,
      skill:[{skill_id:100,skill_name:"Java"}]},
    {id:11,name:"Ramya",date:"09/12/2020",gender:"female",salary:3400000,
      skill:[{skill_id:102,skill_name:"c"}]}, 
    {id:12,name:"AbhiRam",date:"09/11/2010",gender:"others",salary:700000,
      skill:[{skill_id:104,skill_name:"c++"}]},
    {id:10,name:"Priya",date:"12/12/2020",gender:"male",salary:150000,
      skill:[{skill_id:105,skill_name:"php"}]}
  ]
  jsonVal={name:"Ram",age:25,address:"Chennai"};
  months=["jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"];
  




}
