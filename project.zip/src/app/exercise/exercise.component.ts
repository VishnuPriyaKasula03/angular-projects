import { Component, OnInit } from '@angular/core';
import { Employee } from '../Employee';

@Component({
  selector: 'app-exercise',
  templateUrl: './exercise.component.html',
  styleUrls: ['./exercise.component.css']
})
export class ExerciseComponent implements OnInit
 {
  emp:Employee={
    id:10,
    name:"ramu",
    salary:200000,
    permanent:"Yes",
    department:{dept_id:1,dept_name:"payroll"},
    skill:[
    {skill_id:100,skill_name:"java"},
    {skill_id:101,skill_name:"c++"},
    {skill_id:102,skill_name:"oracle"}]
  };
  constructor() { }

  ngOnInit(): void {
  }

}
