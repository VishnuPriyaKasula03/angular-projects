import { HomepipePipe } from './homepipe.pipe';

describe('HomepipePipe', () => {
  it('create an instance', () => {
    const pipe = new HomepipePipe();
    expect(pipe).toBeTruthy();
  });
});
