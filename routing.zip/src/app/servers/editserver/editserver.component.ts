import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editserver',
  templateUrl: './editserver.component.html',
  styleUrls: ['./editserver.component.css']
})
export class EditserverComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
